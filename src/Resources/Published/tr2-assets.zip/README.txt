Copy the Moveables.xml and SpriteSequences.xml files to your local copy of TombEditor.

E.g. C:\Tomb Editor\Catalogs\Engines\TR2
